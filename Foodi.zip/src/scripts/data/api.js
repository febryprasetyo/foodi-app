import data from '../../public/data/DATA.json';

export const restaurantData = () => {
  return data.restaurants;
};
